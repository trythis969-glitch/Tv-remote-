package com.crowntv.remote;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.ConsumerIrManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    static final String[] NAMES = {
            "POWER", "MUTE", "SOURCE",
            "VOL+", "VOL-", "MENU",
            "CH+", "CH-", "BACK",
            "UP", "DOWN", "OK",
            "LEFT", "RIGHT"
    };

    ConsumerIrManager ir;
    SharedPreferences prefs;
    final Handler handler = new Handler(Looper.getMainLooper());
    final Map<String, Button> remoteButtons = new HashMap<>();

    Spinner target;
    RadioButton rbCmd;
    EditText etAddr, etCmd, etDelay;
    TextView info;
    Button btnStart;
    boolean running = false;
    int pos = -1;

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    Button mk(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    LinearLayout row(Button... bs) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        for (Button b : bs) {
            r.addView(b, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        }
        return r;
    }

    TextView label(String t, int sp) {
        TextView tv = new TextView(this);
        tv.setText(t);
        tv.setTextSize(sp);
        tv.setPadding(0, dp(8), 0, dp(4));
        return tv;
    }

    EditText numField(String hint, String val) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setHint(hint);
        e.setText(val);
        return e;
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    int num(EditText e, int def) {
        try {
            return Integer.parseInt(e.getText().toString().trim());
        } catch (Exception x) {
            return def;
        }
    }

    int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }

    // NEC protocol: 38 kHz, 9 ms + 4.5 ms header, 32 data bits (LSB first)
    int[] nec(int addr, int cmd) {
        long data = (addr & 0xFFL) | ((~addr & 0xFFL) << 8)
                | ((cmd & 0xFFL) << 16) | ((~cmd & 0xFFL) << 24);
        int[] p = new int[67];
        int i = 0;
        p[i++] = 9000;
        p[i++] = 4500;
        for (int b = 0; b < 32; b++) {
            p[i++] = 560;
            p[i++] = (((data >> b) & 1L) == 1L) ? 1690 : 560;
        }
        p[i++] = 560;
        return p;
    }

    void send(int a, int c) {
        if (ir == null || !ir.hasIrEmitter()) {
            toast("Is phone me IR blaster nahi mila");
            return;
        }
        ir.transmit(38000, nec(a, c));
    }

    int curAddr() {
        return rbCmd.isChecked() ? clamp(num(etAddr, 0)) : clamp(pos);
    }

    int curCmd() {
        return rbCmd.isChecked() ? clamp(pos) : clamp(num(etCmd, 8));
    }

    void sendCurrent() {
        if (pos < 0) return;
        int a = curAddr(), c = curCmd();
        send(a, c);
        info.setText(String.format("Bheja: address=%d (0x%02X)   command=%d (0x%02X)", a, a, c, c));
    }

    final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            pos++;
            if (pos > 255) {
                pos = 255;
                stopScan();
                toast("Scan khatam (0 se 255)");
                return;
            }
            sendCurrent();
            handler.postDelayed(this, Math.max(150, num(etDelay, 700)));
        }
    };

    void startScan() {
        running = true;
        btnStart.setText("Stop");
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    void stopScan() {
        running = false;
        handler.removeCallbacks(tick);
        btnStart.setText("Start scan");
    }

    void updateLabels() {
        for (String n : NAMES) {
            Button b = remoteButtons.get(n);
            if (b != null) b.setText(prefs.getString(n, null) == null ? n + " ?" : n);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ir = (ConsumerIrManager) getSystemService(Context.CONSUMER_IR_SERVICE);
        prefs = getSharedPreferences("codes", MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(24));
        sv.addView(root);
        setContentView(sv);

        boolean has = ir != null && ir.hasIrEmitter();
        root.addView(label(has ? "IR blaster mila: OK" : "IR blaster NAHI mila - app kaam nahi karega", 16));

        // ---------- Remote ----------
        root.addView(label("REMOTE  (? wale button pehle learn karo)", 18));
        for (int i = 0; i < NAMES.length; i += 3) {
            int n = Math.min(3, NAMES.length - i);
            Button[] bs = new Button[n];
            for (int j = 0; j < n; j++) {
                final String name = NAMES[i + j];
                bs[j] = mk(name, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String s = prefs.getString(name, null);
                        if (s == null) {
                            toast(name + " abhi learn nahi hua");
                            return;
                        }
                        String[] p = s.split(",");
                        send(Integer.parseInt(p[0]), Integer.parseInt(p[1]));
                    }
                });
                remoteButtons.put(name, bs[j]);
            }
            root.addView(row(bs));
        }

        // ---------- Learn ----------
        root.addView(label("CODE DHUNDHO (LEARN)", 18));
        root.addView(label("1) Neeche se button chuno (pehle POWER).\n"
                + "2) Phone ka IR dot TV ki taraf rakho, Start scan dabao.\n"
                + "3) Jaise hi TV react kare, Stop dabao. Thoda late ho gaye to 'Back' se ek-ek peeche jao jab tak TV dobara react kare.\n"
                + "4) 'Save' dabao. Phir dusre button ke liye same address par command-scan karo.", 14));

        target = new Spinner(this);
        target.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, NAMES));
        root.addView(target);

        RadioGroup rg = new RadioGroup(this);
        rbCmd = new RadioButton(this);
        rbCmd.setText("Command scan (address fix, command 0-255)");
        RadioButton rbAddr = new RadioButton(this);
        rbAddr.setText("Address scan (command fix, address 0-255)");
        rg.addView(rbCmd);
        rg.addView(rbAddr);
        rbCmd.setChecked(true);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int id) {
                stopScan();
                pos = -1;
            }
        });
        root.addView(rg);

        etAddr = numField("Address", "0");
        etCmd = numField("Command", "8");
        etDelay = numField("Delay ms", "700");
        root.addView(label("Address (command scan me use hota hai)", 13));
        root.addView(etAddr);
        root.addView(label("Command (address scan me use hota hai)", 13));
        root.addView(etCmd);
        root.addView(label("Har code ke beech delay (ms)", 13));
        root.addView(etDelay);

        info = label("Abhi kuch nahi bheja", 15);
        root.addView(info);

        btnStart = mk("Start scan", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (running) stopScan(); else startScan();
            }
        });
        Button back = mk("< Back", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopScan();
                pos = Math.max(0, pos - 1);
                sendCurrent();
            }
        });
        Button next = mk("Next >", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopScan();
                pos = Math.min(255, pos + 1);
                sendCurrent();
            }
        });
        root.addView(row(btnStart, back, next));

        Button again = mk("Dobara bhejo", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCurrent();
            }
        });
        Button reset = mk("Reset (0 se)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopScan();
                pos = -1;
                info.setText("Reset ho gaya");
            }
        });
        root.addView(row(again, reset));

        Button save = mk("SAVE - ye code chune hue button ke liye", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pos < 0) {
                    toast("Pehle scan karo");
                    return;
                }
                stopScan();
                String name = (String) target.getSelectedItem();
                int a = curAddr(), c = curCmd();
                prefs.edit().putString(name, a + "," + c).apply();
                updateLabels();
                toast(name + " saved: address=" + a + " command=" + c);
                // agle button ke liye address wahi rakho
                if (rbCmd.isChecked()) etAddr.setText(String.valueOf(a));
            }
        });
        root.addView(save);

        updateLabels();
    }

    @Override
    protected void onDestroy() {
        stopScan();
        super.onDestroy();
    }
}
